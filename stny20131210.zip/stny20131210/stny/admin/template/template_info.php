<?php
class TplInfo {
    public static $name = 'Pure Coorporation';
    public static $description = 'A Simple Company Style Template';
    public static $author = 'HouYu Li';
    public static $email = 'karadog@gmail.com';
    public static $positions = array(
        //'banner', 'left', 'right', 'center', 'top', 'logo', 'footer', 'nav', 
        'banner', 'right', 'center', 'top', 'logo', 'footer', 'nav', 
        'newsflash', 'user1', 'user2', 'user3'
    );
}
?>