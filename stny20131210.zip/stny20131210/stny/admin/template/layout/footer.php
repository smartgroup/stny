<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
Html::includeJs('/thickbox.js');
?>
        	<!--div id="footer">
                Copyright © 2010 SiteStar.cn All Rights Reserved
        	</div-->
		</div>

	</body>
</html>