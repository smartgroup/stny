<?php
include "navigation/$nav_path/index.html";
?>