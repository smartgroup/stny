<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

echo $html;
?>
<div class="clearer"></div>
