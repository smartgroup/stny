<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
?>
<p class="statichtml"><?php echo $curr_scontent->content; ?></p>