<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
?>
<div class="blockwrapper">
<?php echo $counter_title.SITE_COUNTER_NUM; ?>
</div>
