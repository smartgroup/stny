<?php if (!defined('IN_CONTEXT')) die('access violation error!'); ?>
<script type="text/javascript" language="javascript">
<!--
    select_for_menu_item('<?php echo $type_text.' - '.$name; ?>', '<?php echo $id; ?>');
//-->
</script>
