<?php
if (!defined('IN_CONTEXT')) die('access violation error!');
?>
<img src="<?php echo $img_src; ?>" alt="<?php echo $img_desc; ?>"<?php echo $str_img_width.$str_img_height; ?> />