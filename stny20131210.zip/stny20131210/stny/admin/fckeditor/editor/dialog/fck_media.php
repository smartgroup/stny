<?php
require_once(dirname(__FILE__)."/../../common.inc.php");
?>
<html>
<head>
<title><?php _e('Insert Media');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>
.td{font-size:10pt;}
</style>
<script src="common/fck_dialog_common.js" type="text/javascript"></script>
<script language=javascript>
var oEditor	= window.parent.InnerDialogLoaded() ;
var oDOM		= oEditor.FCK.EditorDocument ;
var FCK = oEditor.FCK;

window.onload = function()
{
	oEditor.FCKLanguageManager.TranslatePage(document) ;
	window.parent.SetOkButton( true ) ;
}

function Ok()
{
  var rurl,rurlname,widthdd,heightdd,doflash,playtype;
  rurl = encodeURI(form1.murl.value);
  widthdd = form1.width.value;
  heightdd = form1.height.value;
  for(i=0;i<document.form1.mplayer.length;i++)
  {
		if(document.form1.mplayer[i].checked){
			playtype = document.form1.mplayer[i].value;
		}
  }
  if(playtype=="rm"
   || (playtype=="-" && (rurl.indexOf('.rm')>0 || rurl.indexOf('.rmvb')>0 || rurl.indexOf('.ram')>0)) )
  {
    revalue = "<embed src='"+ rurl +"' quality='hight' wmode='transparent' type='audio/x-pn-realaudio-plugin' autostart='true' controls='IMAGEWINDOW,ControlPanel,StatusBar' console='Clip1' width='"+ widthdd +"' height='"+ heightdd +"'></embed>\r\n";
  }
  else
  {
  	revalue = "";
  	revalue += "<embed src='"+ rurl +"' align='baseline' border='0' width='"+ widthdd +"' height='"+ heightdd +"'";
    revalue += "  	type='application/x-mplayer2' pluginspage='http://www.microsoft.com/isapi/redir.dll?prd=windows&amp;sbp=mediaplayer&amp;ar=media&amp;sba=plugin&amp;'";
    revalue += "    name='MediaPlayer' showcontrols='1' showpositioncontrols='0'";
    revalue += "    showaudiocontrols='1' showtracker='1' showdisplay='0' showstatusbar='1' autosize='0'";
    revalue += "    showgotobar='0' showcaptioning='0' autostart='1' autorewind='0'";
    revalue += "    animationatstart='0' transparentatstart='0' allowscan='1'";
    revalue += "    enablecontextmenu='1' clicktoplay='0' invokeurls='1' defaultframe='datawindow'>";
    revalue += "</embed>\r\n";
  }
  FCK.InsertHtml(revalue);
  window.parent.Cancel();
  return true;
}

function SelectMedia(fname)
{
   if(document.all){
     var posLeft = window.event.clientY-100;
     var posTop = window.event.clientX-400;
   }
   else{
     var posLeft = 100;
     var posTop = 100;
   }
   window.open("../../dialog/select_media.php?f="+fname, "popUpMediaWin", "scrollbars=yes,resizable=yes,statebar=no,width=750,height=350,left="+posLeft+", top="+posTop);
}
</script>
</head>
<body leftmargin="0" topmargin="8" bgcolor="#EBF6CD">
  <form name="form1" id="form1">
  	<table border="0" width="98%" align="center">
    <tr height="30"> 
      <td align="right"><?php _e('Url');?>：</td>
      <td colspan="3" nowrap>
      	<input name="murl" type="text" id="murl" style="width:200px" value="http://">
      	<input type="button" name="selmedia" class="binput" style="width:60px" value="<?php _e('Browse Server ...');?>" onClick="SelectMedia('form1.murl')">
      </td>
    </tr>
    <tr height="30"> 
      <td align="right"><?php _e('Width');?>：</td>
      <td colspan="3" nowrap>
      	<input type="text" name="width" size="8" value="350" >
        &nbsp;&nbsp;&nbsp; <?php _e('Height');?>：
        <input name="height" type="text" id="height" value="68" size="8" >
       </td>
    </tr>
    <tr height="30"> 
      <td align="right"><?php _e('Player');?>：</td>
      <td colspan="3" nowrap>
      	<input type='radio' name='mplayer' value='-' checked>
      	<?php _e('Automatic selection');?>
      	<input type='radio' name='mplayer' value='rm'>
      	RealPlay
      	<input type='radio' name='mplayer' value='wm'>
      	WM Player
      </td>
    </tr>
  </table>
  </form>
</body>
</HTML>

