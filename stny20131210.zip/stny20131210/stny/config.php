<?php 
if (!defined('IN_CONTEXT')) die('access violation error!');
class Config {
public static $mysql_ext = 'mysql';
public static $db_host = 'localhost';
public static $db_user = 'root';
public static $db_pass = '123';
public static $db_name = 'stny';
public static $port = '3306';
public static $mysqli_charset = 'utf8';
public static $tbl_prefix = 'ss_';
public static $cookie_prefix = 'foMHlj_';
public static $enable_db_debug = false;
}?>
