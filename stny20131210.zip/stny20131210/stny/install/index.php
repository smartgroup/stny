<?php
/**
* 自助建站安装程序
* @copyright www.cndns.com
* @date 2010-1-12
*/

define('IN_CONTEXT', 1);
include_once('load.php');
?>