<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SiteStar建站之星安装程序</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="../script/png.js"></script>
</head>

<body>
    <div id="in">
    	<div id="top"><span>SiteStar建站之星安装程序</span></div>
        <div id="banner"></div>
        <div id="center">
        
       	  <div id="left">
            	<ul>
                	<li>欢迎您使用SiteStar</li>
                    <li>检查系统环境</li>
                    <li>配置系统</li>
                    <li class="hov">完成安装</li>
                </ul>
            </div>
            
            <div id="right">   
            	<div id="right_table">
                    <div id="right_table_img"></div>
                    <div id="right_table2">
                    	<div id="right_table2_font">
                            恭喜您，SiteStar已经成功的安装完成！<br />
                            <span>(基于安全的考虑，请在安装完成后删除Install目录)</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div id="footer">
        	<div class="button"><a href="../index.php?_v=preview" target="_blank">返回Sitestar首页</a></div>
        	<div class="button"><a href="../admin" target="_blank">Sitestar后台管理中心</a></div>
      	</div>
    </div>
</body>
</html>
