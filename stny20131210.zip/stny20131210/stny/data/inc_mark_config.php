<?php
$photo_markup = '1';
$photo_markdown = '1';
$photo_marktype = '1';
$photo_wwidth = '400';
$photo_wheight = '300';
$photo_waterpos = '1';
$photo_watertext = 'SiteStar建站之星';
$photo_fontsize = '24';
$photo_fontcolor = '0,0,0';
$photo_marktrans = '75';
$photo_diaphaneity = '100';
$photo_markimg = 'testaabbsml.png';
$photo_thumb = '1';
$photo_twidth = '400';
$photo_theight = '300';
$photo_thumbtrans = '75';
$photo_angle = '0';
$photo_shadowx = '1';
$photo_shadowy = '1';
$photo_shadowcolor = '0,0,0';
?>