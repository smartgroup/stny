<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

class AdminMenuItem extends RecordObject {
}
?>
