<?php


if (!defined('IN_CONTEXT')) die('access violation error!');

/**
 * Module block object
 * 
 */
class Navigation extends RecordObject {
}
?>