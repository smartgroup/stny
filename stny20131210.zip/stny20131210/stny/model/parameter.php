<?php

if (!defined('IN_CONTEXT')) die('access violation error!');

/**
 * Database parameter object
 * 
 */
class Parameter extends RecordObject {
}
?>