<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

class BackgroundMusic extends RecordObject {
}
?>