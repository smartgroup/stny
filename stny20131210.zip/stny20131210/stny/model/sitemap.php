<?php


if (!defined('IN_CONTEXT')) die('access violation error!');

/**
 * Search object
 * 
 */
class Sitemap extends RecordObject {
	
}