<?php


if (!defined('IN_CONTEXT')) die('access violation error!');

/**
 * Bulletin object
 * 
 */
class Bulletin extends RecordObject {
}
?>