<?php
if (!defined('IN_CONTEXT')) die('access violation error!');

class Backup extends RecordObject {
	
}
?>